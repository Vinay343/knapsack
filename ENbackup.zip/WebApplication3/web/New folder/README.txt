A Pen created at CodePen.io. You can find this one at http://codepen.io/mattsince87/pen/XbMzXM.

 This is a Material Design Search bar that i am working on. Inspired by <a href="http://google.com/design/spec">Google Material Design</a>